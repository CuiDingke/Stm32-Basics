#include "stm32f10x.h"
#include "myiic.h"
#include "24cxx.h"
#include "delay.h"

const u8 TEXT_Buffer[]={"www.hist.edu.cn"};
#define SIZE sizeof(TEXT_Buffer)	
int main(void)
{
     uint8_t datatemp[SIZE];
     delay_init();	 
     AT24CXX_Init();	
 while(AT24CXX_Check()) 
	  {
    //�������������룬��printr();		
	  }
 while (1)
    {
     AT24CXX_Write(0,(uint8_t*)TEXT_Buffer,SIZE);
     delay_ms(10);			
     AT24CXX_Read(0,datatemp,SIZE);					
    }
}



/***********************************�ļ�����***********************************/
